/**
 * coordinates.h
 * 
 * values of 0 and below not accepted
 * +x goes to the right
 * +y goes down
 */

struct Coordinates {
    int x = 0;
    int y = 0;
};